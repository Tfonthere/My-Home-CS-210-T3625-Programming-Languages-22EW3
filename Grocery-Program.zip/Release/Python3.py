import re
import string
import os.path
from os import path

def CountAll():
    #Opens file in read mode
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #Creates a dictionary for storage 
    dictionary = dict()

    #Check lines of inputted file
    for line in text:
        #removes spaces and newline characters
        line = line.strip()

        #Converts inputted text to lowercase
        word = line.lower()
        
        #Checks imputted word if entry has been aded to the dictionary previously 
        if word in dictionary:
            #Increment the frequency of word usage
            dictionary[word] = dictionary[word] + 1
        else:
            #adds new words to the dictionary with a value of 1
            dictionary[word] = 1

    #Prints contents of dictionary
    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])

    #Closes the currently open document.
    text.close()

def CountInstances(searchTerm):

    #turns inputted search terms to lowercase
    searchTerm = searchTerm.lower()

    #Opens file in read mode
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #variable to track frequency of search turms being located
    wordCount = 0

    #Checks lines of the input file
    for line in text:
        #remove spaces
        line = line.strip()

        #convert characters to lowercase
        word = line.lower()
        
        #Checks if word is equal inputted words
        if word == searchTerm:
            #Increments frequency of word useage
            wordCount += 1

    #Return number of times search term was located
    return wordCount

    #Closes document 
    text.close()


#Counts the frequency of each item, then writes it to frequency.dat

#       frequency.dat
def CollectData():
    #Opens the inputted file in read mode
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #Create and/or write the file frequency.dat
    frequency = open("frequency.dat", "w")

    #Create an empty dictionary to store words
    dictionary = dict()

    #Checks lines of inputted file
    for line in text:
        #removes spaces
        line = line.strip()

        #Converts characters to lowercase
        word = line.lower()
        
        #Checks if imputted word is present in dictionary
        if word in dictionary:
            #Increment frequency of word useage
            dictionary[word] = dictionary[word] + 1
        else:
            #If a given word is new to dictionary, add to dictionary with a value of 1
            dictionary[word] = 1

    #Writes key & value pairs to frequency.dat
    for key in list (dictionary.keys()):
        #Format key-value paira as strings.
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    #Close opened document
    text.close()
    frequency.close()